#!/usr/bin/env node
import { createRequire as __dwaraRequire } from 'node:module';
const require = __dwaraRequire(import.meta.url);
import {
  __commonJS,
  __toESM
} from "./chunk-XGT6W2ZI.js";

// ../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/quote.js
var require_quote = __commonJS({
  "../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/quote.js"(exports, module) {
    "use strict";
    var OPS = (
      /** @type {const} */
      [
        "||",
        "&&",
        ";;",
        "|&",
        "<(",
        "<<<",
        ">>",
        ">&",
        "<&",
        "&",
        ";",
        "(",
        ")",
        "|",
        "<",
        ">"
      ]
    );
    var LINE_TERMINATORS = /[\n\r\u2028\u2029]/;
    var GLOB_SHELL_SPECIAL = /[\s#!"$&'():;<=>@\\^`|]/g;
    module.exports = function quote(xs) {
      return xs.map(function(s) {
        if (s === "") {
          return (
            /** @type {const} */
            "''"
          );
        }
        if (s && typeof s === "object") {
          if ("op" in s && s.op === "glob") {
            if (typeof s.pattern !== "string") {
              throw new TypeError("glob token requires a string `pattern`");
            }
            if (LINE_TERMINATORS.test(s.pattern)) {
              throw new TypeError("glob `pattern` must not contain line terminators");
            }
            return s.pattern.replace(GLOB_SHELL_SPECIAL, "\\$&");
          }
          if ("op" in s && typeof s.op === "string") {
            if (OPS.indexOf(s.op) < 0) {
              throw new TypeError("invalid `op` value: " + JSON.stringify(s.op));
            }
            return s.op.replace(/[\s\S]/g, "\\$&");
          }
          if ("comment" in s && typeof s.comment === "string") {
            if (LINE_TERMINATORS.test(s.comment)) {
              throw new TypeError("`comment` must not contain line terminators");
            }
            return "#" + s.comment;
          }
          throw new TypeError("unrecognized object token shape");
        }
        if (/["\s\\]/.test(s) && !/'/.test(s)) {
          return "'" + s.replace(/(['])/g, "\\$1") + "'";
        }
        if (/["'\s]/.test(s)) {
          return '"' + s.replace(/(["\\$`!])/g, "\\$1") + '"';
        }
        return String(s).replace(/([A-Za-z]:)?([#!"$&'()*,:;<=>?@[\\\]^`{|}~])/g, "$1\\$2");
      }).join(" ");
    };
  }
});

// ../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/parse.js
var require_parse = __commonJS({
  "../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/parse.js"(exports, module) {
    "use strict";
    var CONTROL = (
      /** @type {const} */
      "(?:" + /** @type {const} */
      [
        "\\|\\|",
        "\\&\\&",
        ";;",
        "\\|\\&",
        "\\<\\(",
        "\\<\\<\\<",
        ">>",
        ">\\&",
        "<\\&",
        "[&;()|<>]"
      ].join(
        /** @type {const} */
        "|"
      ) + /** @type {const} */
      ")"
    );
    var controlRE = new RegExp("^" + CONTROL + "$");
    var META = (
      /** @type {const} */
      "|&;()<> \\t"
    );
    var SINGLE_QUOTE = (
      /** @type {const} */
      "'([^']*?)'"
    );
    var DOUBLE_QUOTE = (
      /** @type {const} */
      '"((\\\\"|[^"])*?)"'
    );
    var hash = /^#$/;
    var SQ = (
      /** @type {const} */
      "'"
    );
    var DQ = (
      /** @type {const} */
      '"'
    );
    var DS = (
      /** @type {const} */
      "$"
    );
    var TOKEN = "";
    var mult = (
      /** @type {const} */
      4294967296
    );
    for (i = 0; i < 4; i++) {
      TOKEN += (mult * Math.random()).toString(16);
    }
    var i;
    var startsWithToken = new RegExp("^" + TOKEN);
    function matchAll(s, r) {
      var origIndex = r.lastIndex;
      var matches = [];
      var matchObj;
      while (matchObj = r.exec(s)) {
        matches[matches.length] = matchObj;
        if (r.lastIndex === matchObj.index) {
          r.lastIndex += 1;
        }
      }
      r.lastIndex = origIndex;
      return matches;
    }
    function getVar(env, pre, key) {
      var r = typeof env === "function" ? env(key) : env[key];
      if (typeof r === "undefined" && key != "") {
        r = "";
      } else if (typeof r === "undefined") {
        r = "$";
      }
      if (typeof r === "object") {
        return pre + TOKEN + JSON.stringify(r) + TOKEN;
      }
      return pre + r;
    }
    function parseInternal(string, env, opts) {
      if (!opts) {
        opts = {};
      }
      var BS = opts.escape || "\\";
      var ifs = opts.splitUnquoted === true ? " 	\n" : typeof opts.splitUnquoted === "string" ? opts.splitUnquoted : "";
      var BAREWORD = "(\\" + BS + `['"` + META + `]|[^\\s'"` + META + "])+";
      var chunker = new RegExp([
        "(" + CONTROL + ")",
        // control chars
        "(" + BAREWORD + "|" + DOUBLE_QUOTE + "|" + SINGLE_QUOTE + ")+"
      ].join("|"), "g");
      var matches = matchAll(string, chunker);
      if (matches.length === 0) {
        return [];
      }
      if (!env) {
        env = {};
      }
      var commented = false;
      return matches.map(function(match) {
        var s = match[0];
        if (!s || commented) {
          return void 0;
        }
        if (controlRE.test(s)) {
          return (
            /** @type {ControlOperator} */
            { op: s }
          );
        }
        var quote = false;
        var esc = false;
        var out = "";
        var words = [];
        var sawQuote = false;
        var pendingNw = null;
        var isGlob = false;
        var i2;
        function parseEnvVar() {
          i2 += 1;
          var varend;
          var varname;
          var char = s.charAt(i2);
          if (char === "{") {
            i2 += 1;
            if (s.charAt(i2) === "}") {
              throw new Error("Bad substitution: " + s.slice(i2 - 2, i2 + 1));
            }
            var depth = 1;
            varend = i2;
            while (depth > 0 && varend < s.length) {
              if (s.charAt(varend) === "{" && s.charAt(varend - 1) === "$") {
                depth += 1;
              } else if (s.charAt(varend) === "}") {
                depth -= 1;
              }
              varend += 1;
            }
            if (depth !== 0) {
              throw new Error("Bad substitution: " + s.slice(i2));
            }
            varend -= 1;
            varname = s.slice(i2, varend);
            i2 = varend;
          } else if (/[*@#?$!_-]/.test(char)) {
            varname = char;
            i2 += 1;
          } else {
            var slicedFromI = s.slice(i2);
            varend = slicedFromI.match(/[^\w\d_]/);
            if (!varend) {
              varname = slicedFromI;
              i2 = s.length;
            } else {
              varname = slicedFromI.slice(0, varend.index);
              i2 += /** @type {number} */
              varend.index - 1;
            }
          }
          return getVar(
            /** @type {NonNullable<typeof env>} */
            env,
            "",
            varname
          );
        }
        function flushRun() {
          if (pendingNw === null) {
            return;
          }
          if (pendingNw === 0) {
            if (out !== "") {
              words[words.length] = out;
              out = "";
            }
          } else {
            words[words.length] = out;
            out = "";
            for (var fe = 1; fe < pendingNw; fe += 1) {
              words[words.length] = "";
            }
          }
          pendingNw = null;
        }
        for (i2 = 0; i2 < s.length; i2++) {
          var c = s.charAt(i2);
          if (ifs && c !== DS) {
            flushRun();
          }
          isGlob = isGlob || !quote && (c === "*" || c === "?");
          if (esc) {
            out += c;
            esc = false;
          } else if (quote) {
            if (c === quote) {
              quote = false;
            } else if (quote == SQ) {
              out += c;
            } else {
              if (c === BS) {
                i2 += 1;
                c = s.charAt(i2);
                if (c === DQ || c === BS || c === DS) {
                  out += c;
                } else {
                  out += BS + c;
                }
              } else if (c === DS) {
                out += parseEnvVar();
              } else {
                out += c;
              }
            }
          } else if (c === DQ || c === SQ) {
            quote = c;
            sawQuote = true;
          } else if (controlRE.test(c)) {
            return (
              /** @type {ControlOperator} */
              { op: s }
            );
          } else if (hash.test(c)) {
            commented = true;
            var commentObj = { comment: string.slice(match.index + i2 + 1) };
            if (out.length) {
              return (
                /** @type {const} */
                [out, commentObj]
              );
            }
            return (
              /** @type {const} */
              [commentObj]
            );
          } else if (c === BS) {
            esc = true;
          } else if (c === DS) {
            var value = parseEnvVar();
            if (!ifs) {
              out += value;
            } else {
              for (var vi = 0; vi < value.length; vi += 1) {
                var vc = value.charAt(vi);
                if (ifs.indexOf(vc) < 0) {
                  flushRun();
                  out += vc;
                } else if (pendingNw === null) {
                  pendingNw = vc === " " || vc === "	" || vc === "\n" ? 0 : 1;
                } else if (vc !== " " && vc !== "	" && vc !== "\n") {
                  pendingNw += 1;
                }
              }
            }
          } else {
            out += c;
          }
        }
        if (isGlob) {
          return (
            /** @type {GlobPattern} */
            { op: "glob", pattern: out }
          );
        }
        if (ifs) {
          if (pendingNw !== null && pendingNw > 0) {
            words[words.length] = out;
            out = "";
            for (var te = 1; te < pendingNw; te += 1) {
              words[words.length] = "";
            }
          }
          if (out !== "" || sawQuote && words.length === 0) {
            words[words.length] = out;
          }
          return words;
        }
        return out;
      }).reduce(
        function(prev, arg) {
          if (typeof arg === "undefined") {
            return prev;
          }
          [].concat(arg).forEach(function(entry) {
            prev[prev.length] = entry;
          });
          return prev;
        },
        /** @type {ParseEntry[]} */
        []
      );
    }
    module.exports = function parse2(s, env, opts) {
      var mapped = parseInternal(s, env, opts);
      if (typeof env !== "function") {
        return mapped;
      }
      return mapped.reduce(
        function(acc, s2) {
          if (typeof s2 === "object") {
            acc[acc.length] = s2;
            return acc;
          }
          var xs = s2.split(RegExp("(" + TOKEN + ".*?" + TOKEN + ")", "g"));
          if (xs.length === 1) {
            acc[acc.length] = xs[0];
            return acc;
          }
          xs.filter(Boolean).forEach(function(x) {
            acc[acc.length] = startsWithToken.test(x) ? JSON.parse(x.split(TOKEN)[1]) : x;
          });
          return acc;
        },
        /** @type {ParseEntry[]} */
        []
      );
    };
  }
});

// ../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/index.js
var require_shell_quote = __commonJS({
  "../../node_modules/.pnpm/shell-quote@1.10.0/node_modules/shell-quote/index.js"(exports) {
    "use strict";
    exports.quote = require_quote();
    exports.parse = require_parse();
  }
});

// src/index.ts
import { realpathSync } from "fs";
import { fileURLToPath } from "url";

// src/detect.ts
var import_shell_quote = __toESM(require_shell_quote(), 1);
var REMOTE_VERBS = /* @__PURE__ */ new Set(["ssh", "slogin", "scp", "sftp", "rsync", "mosh"]);
var PATH_VERBS = /* @__PURE__ */ new Set(["scp", "sftp", "rsync"]);
var SHELLS = /* @__PURE__ */ new Set(["sh", "bash", "zsh", "dash", "ksh", "ash"]);
var WRAPPERS = /* @__PURE__ */ new Map([
  ["sudo", 0],
  ["doas", 0],
  ["env", 0],
  ["command", 0],
  ["builtin", 0],
  ["exec", 0],
  ["nohup", 0],
  ["stdbuf", 0],
  ["timeout", 1],
  ["nice", 0],
  ["ionice", 0]
]);
var SSH_OPTS_WITH_VALUE = /* @__PURE__ */ new Set([
  "-o",
  "-i",
  "-p",
  "-l",
  "-J",
  "-F",
  "-b",
  "-c",
  "-D",
  "-E",
  "-e",
  "-I",
  "-L",
  "-m",
  "-O",
  "-Q",
  "-R",
  "-S",
  "-W",
  "-w"
]);
var SEPARATORS = /* @__PURE__ */ new Set([";", "&&", "||", "|", "&", "\n", "(", ")", "{", "}"]);
var VARIABLE = /\$\{?[A-Za-z_][A-Za-z0-9_]*\}?/;
function namesRemoteVerb(command) {
  return [...REMOTE_VERBS].some(
    (verb) => new RegExp(`(^|[\\s;&|(\`'"/])${verb}(\\s|$)`).test(command)
  );
}
var UNKNOWN = /* @__PURE__ */ Symbol("unknown");
function inspect(command, managed) {
  if (managed.length === 0) return { kind: "allow" };
  const hosts = new Set(managed);
  return walk(command, hosts, 0);
}
function walk(command, hosts, depth) {
  if (depth > 8) {
    return { kind: "unreadable", reason: "nested too deeply to read with confidence" };
  }
  if (VARIABLE.test(command) && namesRemoteVerb(command)) {
    return {
      kind: "unreadable",
      reason: "the destination comes from a variable, which this hook cannot read"
    };
  }
  for (const inner of substitutions(command)) {
    const verdict = walk(inner, hosts, depth + 1);
    if (verdict.kind !== "allow") return verdict;
  }
  let parsed;
  try {
    parsed = (0, import_shell_quote.parse)(command);
  } catch {
    return mentionsHost(command, hosts) ? { kind: "unreadable", reason: "could not be parsed, and names a managed host" } : { kind: "allow" };
  }
  for (const segment of segments(parsed)) {
    const verdict = inspectSegment(segment, hosts, depth, command);
    if (verdict.kind !== "allow") return verdict;
  }
  return { kind: "allow" };
}
function substitutions(command) {
  const found = [];
  for (let i = 0; i < command.length; i += 1) {
    if (command[i] === "$" && command[i + 1] === "(") {
      let depth = 1;
      const start = i + 2;
      let j = start;
      for (; j < command.length && depth > 0; j += 1) {
        if (command[j] === "(") depth += 1;
        else if (command[j] === ")") depth -= 1;
      }
      if (depth === 0) found.push(command.slice(start, j - 1));
      i = j - 1;
      continue;
    }
    if (command[i] === "`") {
      const end = command.indexOf("`", i + 1);
      if (end === -1) break;
      found.push(command.slice(i + 1, end));
      i = end;
    }
  }
  return found;
}
function segments(parsed) {
  const out = [];
  let current = [];
  for (const entry of parsed) {
    if (typeof entry === "string") {
      current.push(stripBackticks(entry));
      continue;
    }
    const op = entry.op;
    if (op === "glob") {
      current.push(UNKNOWN);
      continue;
    }
    if (op !== void 0 && SEPARATORS.has(op)) {
      if (current.length > 0) out.push(current);
      current = [];
      continue;
    }
    current.push(UNKNOWN);
  }
  if (current.length > 0) out.push(current);
  return out;
}
function inspectSegment(tokens, hosts, depth, original) {
  const index = skipPrefixes(tokens);
  if (index >= tokens.length) return { kind: "allow" };
  const head = tokens[index];
  if (head === void 0) return { kind: "allow" };
  if (head === UNKNOWN) {
    return mentionsHost(original, hosts) ? { kind: "unreadable", reason: "the program being run could not be read" } : { kind: "allow" };
  }
  const verb = basename(head);
  if (SHELLS.has(verb)) {
    const flag = tokens.indexOf("-c", index);
    if (flag === -1) return { kind: "allow" };
    const inner = tokens[flag + 1];
    if (inner === void 0) return { kind: "allow" };
    if (inner === UNKNOWN || inner === "") {
      return { kind: "unreadable", reason: `${verb} -c was given a command this hook cannot read` };
    }
    return walk(inner, hosts, depth + 1);
  }
  if (verb === "eval") {
    const rest = tokens.slice(index + 1);
    if (rest.some((token) => token === UNKNOWN || token === "")) {
      return { kind: "unreadable", reason: "eval was given a command this hook cannot read" };
    }
    return walk(rest.join(" "), hosts, depth + 1);
  }
  if (verb === "xargs") {
    return inspectXargs(tokens.slice(index + 1), hosts);
  }
  if (!REMOTE_VERBS.has(verb)) return { kind: "allow" };
  return inspectRemote(verb, tokens.slice(index + 1), hosts);
}
function inspectXargs(rest, hosts) {
  for (const token of rest) {
    if (token === UNKNOWN) continue;
    if (token.startsWith("-")) continue;
    const verb = basename(token);
    if (!REMOTE_VERBS.has(verb)) return { kind: "allow" };
    const named = [...hosts].find((host) => rest.includes(host));
    return named === void 0 ? {
      kind: "unreadable",
      reason: `xargs would run ${verb} with hosts read from input, which this hook cannot see`
    } : { kind: "deny", verb, host: named };
  }
  return { kind: "allow" };
}
function inspectRemote(verb, args, hosts) {
  const unresolved = args.some((token) => token === UNKNOWN);
  if (PATH_VERBS.has(verb)) {
    for (const token of args) {
      if (token === UNKNOWN) continue;
      const colon = token.indexOf(":");
      if (colon <= 0) continue;
      const host = stripUser(token.slice(0, colon));
      if (hosts.has(host)) return { kind: "deny", verb, host };
    }
    if (unresolved) {
      return {
        kind: "unreadable",
        reason: `${verb} was given a destination this hook cannot read`
      };
    }
  }
  for (let i = 0; i < args.length; i += 1) {
    const token = args[i];
    if (token === UNKNOWN) {
      return {
        kind: "unreadable",
        reason: `${verb} was given a destination this hook cannot read`
      };
    }
    if (token === void 0) break;
    if (token.startsWith("-")) {
      if (SSH_OPTS_WITH_VALUE.has(token)) i += 1;
      continue;
    }
    if (token === "") {
      return {
        kind: "unreadable",
        reason: `${verb} was given a destination from a variable, which this hook cannot read`
      };
    }
    if (token.includes("$")) {
      return {
        kind: "unreadable",
        reason: `${verb} was given a destination built by substitution, which this hook cannot read`
      };
    }
    const host = stripUser(token);
    if (hosts.has(host)) return { kind: "deny", verb, host };
    return { kind: "allow" };
  }
  return unresolved ? { kind: "unreadable", reason: `${verb} was given a destination this hook cannot read` } : { kind: "allow" };
}
function skipPrefixes(tokens) {
  let index = 0;
  for (; ; ) {
    const token = tokens[index];
    if (token === void 0 || token === UNKNOWN) return index;
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(token)) {
      index += 1;
      continue;
    }
    const skip = WRAPPERS.get(basename(token));
    if (skip === void 0) return index;
    index += 1 + skip;
    while (typeof tokens[index] === "string" && tokens[index].startsWith("-")) {
      index += 2;
    }
  }
}
function mentionsHost(command, hosts) {
  return [...hosts].some((host) => command.includes(host));
}
function stripBackticks(token) {
  return token.replace(/^`+/, "").replace(/`+$/, "");
}
function basename(token) {
  const slash = token.lastIndexOf("/");
  return slash === -1 ? token : token.slice(slash + 1);
}
function stripUser(target) {
  const at = target.lastIndexOf("@");
  return at === -1 ? target : target.slice(at + 1);
}

// src/hosts.ts
import { access } from "fs/promises";
import { join } from "path";
var NONE = { hosts: [] };
async function managedHosts(options) {
  const cwd = options.cwd ?? process.cwd();
  const policyPath = options.policyPath ?? process.env["DWARA_POLICY"] ?? join(cwd, ".dwara", "policy.yaml");
  try {
    await access(policyPath);
  } catch {
    return NONE;
  }
  const { loadPolicy, matchesHost, parseSshConfig } = await import("./dist-MOT27LB7.js");
  let patterns;
  try {
    const loaded = await loadPolicy(policyPath);
    patterns = loaded.policy.hosts.map((rule) => rule.match);
  } catch {
    return NONE;
  }
  if (patterns.length === 0) return NONE;
  const literals = patterns.filter((pattern) => !/[*?]/.test(pattern));
  const wildcards = patterns.filter((pattern) => /[*?]/.test(pattern));
  let expanded = [];
  if (wildcards.length > 0) {
    try {
      const sshConfigPath = options.sshConfigPath ?? process.env["DWARA_SSH_CONFIG"] ?? "~/.ssh/config";
      const config = await parseSshConfig(sshConfigPath);
      expanded = config.hosts.filter(
        (host) => wildcards.some((pattern) => matchesHost(pattern, host))
      );
    } catch {
      expanded = [];
    }
  }
  const hosts = [.../* @__PURE__ */ new Set([...literals, ...expanded])].sort();
  return hosts.length === 0 ? NONE : { hosts, policyPath };
}

// src/evasions.ts
var CORPUS_HOSTS = [
  "lab-api",
  "lab-db",
  "lab-cache",
  "lab-queue",
  "lab-staging"
];
var DIRECT = [
  { command: "ssh lab-api", expect: "deny", why: "the plainest case there is" },
  {
    command: "ssh dwara@lab-api 'systemctl restart nginx'",
    expect: "deny",
    why: "a user@host form with a remote command"
  },
  { command: "ssh lab-db uptime", expect: "deny", why: "a different managed host" },
  {
    command: "ssh -o StrictHostKeyChecking=no lab-api",
    expect: "deny",
    why: "options before the host must not hide it"
  },
  {
    command: "ssh -i ~/.ssh/id_ed25519 -p 2201 lab-api",
    expect: "deny",
    why: "several option pairs before the host"
  },
  {
    command: "ssh -J bastion lab-api",
    expect: "deny",
    why: "reached through a jump host; the destination is still managed"
  },
  {
    command: "scp ./patch.conf lab-api:/etc/nginx/conf.d/",
    expect: "deny",
    why: "copying a file in is a change, and scp is the obvious way round edit_config"
  },
  {
    command: "scp lab-api:/var/log/syslog .",
    expect: "deny",
    why: "copying out bypasses the redactor entirely"
  },
  {
    command: "rsync -avz ./dist/ lab-api:/srv/app/",
    expect: "deny",
    why: "rsync is scp with more reach"
  },
  { command: "sftp lab-api", expect: "deny", why: "another file transfer route" },
  { command: "mosh lab-api", expect: "deny", why: "a shell by another name" },
  {
    command: "/usr/bin/ssh lab-api",
    expect: "deny",
    why: "an absolute path; the verb must be matched on its basename"
  },
  {
    command: "ssh	lab-api",
    expect: "deny",
    why: "a tab rather than a space still separates tokens"
  }
];
var WRAPPED = [
  {
    command: "DEBUG=1 ssh lab-api",
    expect: "deny",
    why: "an environment prefix sits in front of the verb"
  },
  {
    command: "FOO=1 BAR=2 ssh lab-api",
    expect: "deny",
    why: "several environment prefixes"
  },
  { command: "sudo ssh lab-api", expect: "deny", why: "a wrapper the walker must step past" },
  { command: "env ssh lab-api", expect: "deny", why: "env as a wrapper" },
  { command: "timeout 5 ssh lab-api", expect: "deny", why: "timeout takes an argument first" },
  { command: "nohup ssh lab-api &", expect: "deny", why: "backgrounded" },
  { command: "nice -n 10 ssh lab-api", expect: "deny", why: "nice with a flag pair" },
  {
    command: "command ssh lab-api",
    expect: "deny",
    why: "the shell builtin that bypasses aliases"
  },
  { command: 'bash -c "ssh lab-api hostname"', expect: "deny", why: "one level of bash -c" },
  { command: "sh -c 'ssh lab-api'", expect: "deny", why: "sh rather than bash" },
  {
    command: `bash -c 'bash -c "ssh lab-api"'`,
    expect: "deny",
    why: "two levels; recursion cannot stop at one"
  },
  { command: 'eval "ssh lab-api"', expect: "deny", why: "eval takes a string to run" },
  { command: 'zsh -c "ssh lab-api"', expect: "deny", why: "a third shell" },
  {
    command: "$(ssh lab-api hostname)",
    expect: "deny",
    why: "command substitution; the parser flattens it into ordinary tokens"
  },
  {
    command: 'echo "$(ssh lab-api hostname)"',
    expect: "deny",
    why: "substitution nested inside a quoted argument"
  },
  {
    command: "`ssh lab-api hostname`",
    expect: "deny",
    why: 'backticks are NOT interpreted: the verb token arrives as "`ssh"'
  },
  {
    command: "echo `ssh lab-api uptime`",
    expect: "deny",
    why: "backticks as an argument, same stray-character problem"
  },
  { command: "ssh lab-api; echo done", expect: "deny", why: "a semicolon separator" },
  { command: "echo hi && ssh lab-api", expect: "deny", why: "after a conditional" },
  { command: "false || ssh lab-api", expect: "deny", why: "after an or" },
  { command: "echo lab-api | ssh lab-api", expect: "deny", why: "after a pipe" },
  {
    command: "s".concat("''", "sh lab-api"),
    expect: "deny",
    why: "quote splitting, which the parser normalises back to ssh"
  },
  {
    command: "\\ssh lab-api",
    expect: "deny",
    why: "a leading backslash, also normalised away"
  },
  {
    command: "ssh lab-api -- systemctl restart nginx",
    expect: "deny",
    why: "a -- separator before the remote command"
  }
];
var INNOCENT = [
  { command: "ssh my-vps", expect: "allow", why: "a host no policy names" },
  { command: "ssh git@github.com", expect: "allow", why: "a forge, not managed infrastructure" },
  { command: "git push origin main", expect: "allow", why: "git over SSH to somewhere unmanaged" },
  { command: "git clone git@github.com:me/repo.git", expect: "allow", why: "cloning" },
  { command: "scp ./a.txt backup-box:/tmp", expect: "allow", why: "scp to an unmanaged host" },
  { command: "rsync -a ./a/ ./b/", expect: "allow", why: "a purely local rsync" },
  { command: "grep ssh /etc/hosts", expect: "allow", why: "the word ssh as a search term" },
  {
    command: 'echo "ssh lab-api"',
    expect: "allow",
    why: "the text as a string argument to echo, not a command being run"
  },
  {
    command: "cat notes.md | grep lab-api",
    expect: "allow",
    why: "a managed hostname appearing as data"
  },
  { command: "dwara doctor", expect: "allow", why: "Dwara itself" },
  { command: "pnpm test", expect: "allow", why: "ordinary development" },
  { command: "ls -la /etc/ssh", expect: "allow", why: "a path that contains ssh" },
  {
    command: "docker ps",
    expect: "allow",
    why: "local docker, which reaches no managed host"
  },
  {
    command: "ssh-keygen -t ed25519 -f ./key",
    expect: "allow",
    why: "ssh-keygen is not ssh and reaches nothing"
  },
  {
    command: "ssh-add ~/.ssh/id_ed25519",
    expect: "allow",
    why: "another ssh- prefixed tool that connects to nothing"
  },
  {
    command: "man ssh",
    expect: "allow",
    why: "ssh as an argument rather than the program"
  },
  {
    command: "which ssh",
    expect: "allow",
    why: "asking where it is, not running it"
  }
];
var UNREADABLE = [
  {
    command: "ssh $HOST",
    expect: "unreadable",
    why: 'the parser yields ["ssh", ""]: the host is erased, so it cannot be cleared'
  },
  {
    command: 'ssh "$TARGET" systemctl restart nginx',
    expect: "unreadable",
    why: "a quoted variable, erased the same way"
  },
  {
    command: "ssh ${HOST}",
    expect: "unreadable",
    why: "brace form, erased the same way"
  },
  {
    command: "ssh lab-$(echo api)",
    expect: "unreadable",
    why: 'a host assembled by substitution; the parser leaves "lab-$" and operators'
  },
  {
    command: "ssh *-api",
    expect: "unreadable",
    why: "a glob in the host position, which the parser hands back unresolved"
  },
  {
    command: "cat hosts.txt | xargs ssh",
    expect: "unreadable",
    why: "the host comes from stdin and is not knowable at hook time"
  },
  {
    command: "cat hosts.txt | xargs -I{} ssh {} uptime",
    expect: "unreadable",
    why: "the same, with a placeholder standing in for the host"
  },
  {
    command: 'bash -c "ssh $H"',
    expect: "unreadable",
    why: "a variable inside a nested shell string"
  },
  {
    command: 'eval "$CMD"',
    expect: "unreadable",
    why: "eval of a variable: the whole command is unknown"
  },
  {
    command: "bash ./deploy.sh",
    expect: "allow",
    why: "a script file whose contents the hook cannot see; the dedicated-key setup is what covers this, and blocking every script would make the plugin unusable"
  }
];
var EVASION_CASES = [
  ...DIRECT,
  ...WRAPPED,
  ...INNOCENT,
  ...UNREADABLE
];
var MUST_NOT_PASS = EVASION_CASES.filter(
  (item) => item.expect !== "allow"
);

// src/index.ts
var PACKAGE_NAME = "@dwara/hook";
var VERSION = "0.0.0";
function reply(permissionDecision, permissionDecisionReason) {
  return {
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision,
      permissionDecisionReason
    }
  };
}
function suggestion(command) {
  if (/\b(journalctl|tail|less|cat)\b/.test(command)) {
    return "read_tail_logs for journal or file logs, read_read_config for configuration";
  }
  if (/\bsystemctl\s+(restart|start|stop)/.test(command)) return "reversible_restart_service";
  if (/\bsystemctl\b/.test(command)) return "read_service_status";
  if (/\bdocker\s+restart\b/.test(command)) return "reversible_restart_container";
  if (/\bdocker\b/.test(command)) return "read_docker_ps, read_container_logs";
  if (/\b(df|du)\b/.test(command)) return "read_disk_usage";
  if (/\b(ss|netstat|lsof)\b/.test(command)) return "read_open_ports";
  if (/\b(vi|vim|nano|sed|tee)\b|>/.test(command)) return "config_edit_config";
  if (/\bscp\b|\brsync\b/.test(command)) {
    return "read_read_config to read a file, config_edit_config to change one";
  }
  return "read_host_overview to orient, then the read_* tool for what you need";
}
function decide(command, hosts) {
  const verdict = inspect(command, hosts);
  if (verdict.kind === "allow") {
    return reply("allow", "no managed host involved");
  }
  if (verdict.kind === "deny") {
    return reply(
      "deny",
      [
        `Dwara manages ${verdict.host}, so reaching it with ${verdict.verb} is blocked.`,
        `Use the Dwara tools instead: ${suggestion(command)}.`,
        "They enforce the policy, redact secrets, snapshot before changing anything and",
        "record what happened. A raw shell does none of that."
      ].join(" ")
    );
  }
  return reply(
    "deny",
    [
      `This command could reach a host Dwara manages, and it cannot be read with confidence: ${verdict.reason}.`,
      "It is blocked because guessing is the wrong answer here.",
      `If you need something from a managed host, use the Dwara tools: ${suggestion(command)}.`,
      "If this command has nothing to do with managed hosts, write it without the",
      "variable or substitution so it can be read."
    ].join(" ")
  );
}
async function readStdin() {
  try {
    const chunks = [];
    for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks).toString("utf8");
  } catch {
    return "";
  }
}
async function run(raw) {
  let input;
  try {
    const parsed = JSON.parse(raw);
    input = parsed !== null && typeof parsed === "object" ? parsed : {};
  } catch {
    return reply("allow", "hook input could not be read");
  }
  if (input.tool_name !== "Bash") return reply("allow", "not a shell command");
  const command = input.tool_input?.command;
  if (typeof command !== "string" || command.trim() === "") {
    return reply("allow", "no command to inspect");
  }
  const managed = await managedHosts({
    ...input.cwd === void 0 ? {} : { cwd: input.cwd }
  });
  return decide(command, managed.hosts);
}
async function main() {
  let output;
  try {
    output = await run(await readStdin());
  } catch {
    output = reply("allow", "the Dwara hook failed and did not inspect this command");
  }
  process.stdout.write(`${JSON.stringify(output)}
`);
}
function isEntryPoint() {
  const entry = process.argv[1];
  if (entry === void 0) return false;
  try {
    return realpathSync(entry) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}
if (isEntryPoint()) await main();
export {
  CORPUS_HOSTS,
  EVASION_CASES,
  MUST_NOT_PASS,
  PACKAGE_NAME,
  VERSION,
  decide,
  inspect,
  main,
  managedHosts,
  run
};
